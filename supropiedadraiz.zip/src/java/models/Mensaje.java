package models;
import java.util.HashMap;

public class Mensaje {

    public static HashMap<String, String> espanol = new HashMap<String, String>() {
        {
            put("Bienvenido", "2");
        }

    };

    public static HashMap<String, String> ingles = new HashMap<String, String>() {
        {
            put("Welcome", "2");
        }
        
    };
}
